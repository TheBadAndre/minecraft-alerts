import discord

intents = discord.Intents.all()
client = discord.Client(intents=intents)

@client.event
async def on_ready():
    print(f'{client.user} has connected to Discord!')
    await client.change_presence(activity=discord.Game(name="Watching Your Server"))

@client.event
async def on_message(message):
    if message.content.startswith("/start"):
        await message.channel.send("Hey! The Minecraft server is **ONLINE**, join for play!")
        await message.channel.send("**IP:** ***vivalescimmie.ploudos.me***")
    elif message.content.startswith("/stop"):
        await message.channel.send("The Minecraft server is **OFFLINE**, waits for the command to be used */start*")
        await client.logout()      

client.run('your_token')